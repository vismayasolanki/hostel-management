#pragma once
#include <stdio.h>
#include <stdlib.h>
#include "structure.h"
#include "filetolist.h"
#include "listtofile.h"

void update();

