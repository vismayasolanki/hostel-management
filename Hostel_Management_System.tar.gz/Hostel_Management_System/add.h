#pragma once
#include <stdio.h>
#include <stdlib.h>

#include"structure.h"
#include "filetolist.h"

void sort();
void add();
struct details;

//#include "structure.c"
//This function can add students in hostel
