#pragma once
#include <stdio.h>
#include <stdlib.h>
#include"structure.h"

void filetolist(struct student** students);

