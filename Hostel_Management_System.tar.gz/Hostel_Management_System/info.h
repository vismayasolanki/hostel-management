#include <stdio.h>

void info(void );


void info(void){
    system("cat info.txt");
}