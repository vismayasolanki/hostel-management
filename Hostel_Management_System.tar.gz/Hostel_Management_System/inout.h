#pragma once
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include"structure.h"

#include"filetolist.h"
#include"listtofile.h"


void status();

