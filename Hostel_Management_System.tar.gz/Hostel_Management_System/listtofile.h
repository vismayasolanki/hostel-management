#pragma once
#include <stdio.h>
#include <stdlib.h>
#include"structure.h"
void listtofile(struct student* students);

