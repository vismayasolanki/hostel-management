
#pragma once
#include <stdio.h>
#include"structure.h"
#include"filetolist.h"

void display();
void display_girls();
void display_boys();
void display_all();
void display_batch();

