From the terminal, change to the directory where Hostel_Management_System.tar.gz has been downloaded. Now follow the following 
instructions-
  
 Unzip the zipped file by following command:
 >>> $ tar -zxvf Hostel_Management_System.tar.gz
 
 GO TO THE EXTRACTED DIRECTORY
 Type the following command to compile all the files in our project folder
 >>> $ make all
 
 TO EXECUTE THE PROGRAM RUN FOLLOWING COMMAND
 >>> $ ./main
 
 AFTER PROGRAM STARTS IT ASKS FOR LOGIN CREDENTIALS:
 Following are the Admin Login Details to access the program
 
 Username ->  "username"(USERNAME IS username)
 Password ->  "password"(PASSWORD IS password)
 The double quotes are not included in crdentials.
 
NOW, YOU ARE LOGGED INTO HOSTEL MANAGING SYSTEM!! 

TEAM : 
	Rachapudi Maruthi Sriram - IMT2019068
	Samaksh Dhingra 	 - IMT2019075
  	Shrey Tripathi  	 - IMT2019084
	Vismaya Solanki 	 - IMT2019095
	Abhi Jain        	 - IMT2019501
	Sahil Khare     	 - IMT2019526

----------------------------------------------------------------------------------------------------------------------------------------

IT HELPS THE ADMIN TO KEEP TRACK OF HOSTEL PROPERLY.
ADMIN CAN ADD THE STUDENTS IN HOSTEL IN THEIR RESPECTIVE BATCHES WITH AUTOMATIC ROLL-NUMBER AND ROOM-NUMBER ALLOCATION. 
ADMIN CAN DELETE STUDENTS BY THEIR BATCH AND ROLL NUMBER. 
ADMIN CAN SEE WHICH STUDENTS ARE IN THE HOSTEL AND WHICH ARE OUT. 
ADMIN CAN SEACRH THE INFORMATION OF SOME STUDENTS BY HIS/HER NAME(DON'T REMEMBER THE EXACT NAME? NO WORRIES! ONLY INITIALS WILL DO!) BATCH, ROLLNUMBER. 
ADMIN CAN UPDATE SOME INFORMATION ABOUT STUDENTS. WE CAN SEE THE INFORMATION OF WHOLE BATCH, GIRLS, BOYS SEPERATELY.
ADMIN CAN SEE WHOLE DATABASE USING DISPLAY(SORTED LEXICOGRAPHICALLY)
IT HAS EXHAUSTIVE DATABASE OF STUDENTS COMPRISING DETAILS OF NEARLY 250 STUDENTS DISTRIBUTED IN 4 BATCHES. 
