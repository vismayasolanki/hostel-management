#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include"structure.h"
#include"filetolist.h"
#include"listtofile.h"


void Adjswap(int pos1, int pos2);
int nodesTotal();
void Fullsort();


struct student *head;
